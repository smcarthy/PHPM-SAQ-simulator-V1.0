# Rights, provenance, and sanitization notice

On 2026-11-05, the package provider, Stephen McCarthy, confirmed that all seven
named source files may be used in this publicly available plugin. He stated
that the two Royal College samples are publicly available from the Royal
College and that consent has been obtained for the other five sources. The
submission owner should retain the underlying permission records and provide
them to the platform if requested.

This notice records that representation; it is not a substitute for the
underlying permissions and does not grant users a separate licence to
redistribute the source materials.

## Public-package boundary

The package contains text-only, mechanically generated derivatives. It does
not contain the original PDF or DOCX binaries. This boundary removes embedded
graphics and screenshots, hidden comments, revision identities, office-user
metadata, remote image fields, and other content unnecessary for knowledge
retrieval. Original source files were not modified.

For DOCX sources, Pandoc 3.1.11.1 was used with tracked changes accepted and
comments stripped. For PDF sources, Poppler `pdftotext` 25.03.0 was used in
layout-preserving mode. No AI rewriting or factual supplementation was applied
to the extracted text.

No OCR was added. The Indigenous Health slide deck is image-heavy, so its
native text extract is comparatively sparse; several Leadership and Management
slides are also primarily visual. The plugin must not infer missing image
content. It should use current authoritative sources when the text extract is
insufficient.

## Original source checksums

- `2021 PHPM RC Exam Notes - Leadership and Management .docx` —
  `897aa415b1600a5d376b043c595118480d5f2fc2adfdd566f34f6f8adf45d72b`
- `2025 PHPM RC Exam Notes - Summary of all Topics.docx` —
  `59aabca7e778fdecd5081fb1e1ce6da56a6e4d29e69cf33b4b665cf025c2578d`
- `Leadership & Management 2025.pdf` —
  `b233019d933b525c527da31e2ce82b6bcfd10e9a857782cfdb8baf385202c4eb`
- `Equity and Priority Populations 2025.docx` —
  `e0ada58dec4829f33d94bb14d1192fdbc5928aeb4b62393d0f5663ba7cedd21c`
- `Indigenous Health 2025.pdf` —
  `07aa549c421202d40f7eee3f9a83a9006ad13afa7b1721884da06a31d3feebc3`
- `2025 RC SAQ sample.pdf` —
  `799e98f765c6ac201fecec70a8fe365b2d9cbffc6ab41a2aff562fae4d48deec`
- `2025 RC OSCE sample.pdf` —
  `6aebf46243ad5f98adab089c93b79fa6bfd9beed5ad5275e4ebf83b869200204`

The Royal College samples are public exemplars, not confidential examination
materials. All generated educational content remains provisional until expert
review. Current official documentation and verified expert review take
precedence over these notes and over AI-generated output.
