# Public knowledge derivatives

These seven UTF-8 text files are mechanical, text-only extracts of the source
documents used by the private plugin:

| Included knowledge file | Original source format | Source SHA-256 |
| --- | --- | --- |
| `2021 PHPM RC Exam Notes - Leadership and Management.txt` | DOCX | `897aa415b1600a5d376b043c595118480d5f2fc2adfdd566f34f6f8adf45d72b` |
| `2025 PHPM RC Exam Notes - Summary of all Topics.txt` | DOCX | `59aabca7e778fdecd5081fb1e1ce6da56a6e4d29e69cf33b4b665cf025c2578d` |
| `Leadership & Management 2025.txt` | PDF | `b233019d933b525c527da31e2ce82b6bcfd10e9a857782cfdb8baf385202c4eb` |
| `Equity and Priority Populations 2025.txt` | DOCX | `e0ada58dec4829f33d94bb14d1192fdbc5928aeb4b62393d0f5663ba7cedd21c` |
| `Indigenous Health 2025.txt` | PDF | `07aa549c421202d40f7eee3f9a83a9006ad13afa7b1721884da06a31d3feebc3` |
| `2025 RC SAQ sample.txt` | PDF | `799e98f765c6ac201fecec70a8fe365b2d9cbffc6ab41a2aff562fae4d48deec` |
| `2025 RC OSCE sample.txt` | PDF | `6aebf46243ad5f98adab089c93b79fa6bfd9beed5ad5275e4ebf83b869200204` |

DOCX extracts were produced with tracked changes accepted and comments
stripped. PDF extracts preserve available document text. Images, screenshots,
hidden metadata, remote fields, and source binaries are not included.

No OCR was used. `Indigenous Health 2025.txt` is sparse because many source
slides are image-based; some Leadership and Management slides have the same
limitation. Do not infer omitted visual content or treat the extracts as a
complete transcription of every slide.

These files are educational references, not a substitute for current official
guidance. Current Royal College and other authoritative Canadian sources take
precedence. Missing or ambiguous content must not be silently inferred.
