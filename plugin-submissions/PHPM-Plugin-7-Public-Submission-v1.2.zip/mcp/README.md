# PHPM practice planner MCP server

This bundled stdio MCP server provides two read-only tools:

- `configure_practice_session` validates and normalizes a resident's practice
  format, topic, stage, question count, region, and roleplay preference. It
  returns a reusable prompt for the instruction skill.
- `get_phpm_resource_links` returns the verified PHPM Exam Hub, support,
  privacy, terms, and current Royal College examination-format links.

The server has no dependencies beyond Node.js. It makes no network requests,
stores no state, and does not generate, grade, or modify educational content.
