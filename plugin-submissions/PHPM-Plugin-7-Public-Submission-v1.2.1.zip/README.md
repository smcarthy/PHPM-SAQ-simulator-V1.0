# PHPM Management, Leadership and Program Planning plugin

This package contains the instruction skill and presentation assets for the
PHPM Royal College-style Management, Leadership and Program Planning practice
plugin.

This is an independent educational resource. It is not affiliated with,
sponsored by, or endorsed by the Royal College of Physicians and Surgeons of
Canada. Royal College names and sample materials remain the property of their
respective owner.

## Included

- `.codex-plugin/plugin.json`: package and interface metadata.
- `.mcp.json` and `mcp/server.mjs`: a read-only practice-session planner and
  verified PHPM resource-link tool.
- `skills/instructions/SKILL.md`: the complete instructions exported from the
  current private #7 plugin.
- `skills/instructions/agents/openai.yaml`: skill presentation metadata.
- Root and skill-level icon assets.

## Knowledge files

The package includes seven text-only knowledge derivatives under
`skills/instructions/references/`. They were mechanically extracted from the
seven source files named in the private plugin. The original PDF and DOCX
binaries are deliberately excluded from the public archive so that hidden Word
comments, revision identities, document metadata, remote fields, screenshots,
and embedded third-party graphics are not redistributed.

The package provider confirmed permission for public-plugin use of all seven
sources. `NOTICE.md` and the reference README record the provenance and
sanitization boundary. The extracted text has not been rewritten by AI and is
not represented as official Royal College guidance except where the underlying
source is an official public Royal College sample.

## Publication

Uploading this ZIP creates or updates a submission package; it does not by
itself make the current private plugin ID public. Complete the platform review
and publication steps, then test the approved link from a different account.
If publication creates a new plugin ID, update the Exam Hub launcher to the new
public URL.

The package does not collect data through a developer-operated app or API. The
manifest provides public support, privacy-policy, and terms-of-service pages
hosted with the PHPM Exam Hub.

## MCP capability

Version 1.2.1 includes a bundled, read-only MCP server. It can normalize a resident's
practice-session choices into a reusable prompt and return the verified Hub,
support, privacy, terms, and Royal College format links. It does not generate or
score educational content, access the network, collect data, create accounts,
or persist user input. The instruction skill remains responsible for the actual
practice exercise and formative feedback.

The listing uses the `Productivity` category because its main user-facing
purpose is to plan and run structured study sessions. The descriptions state
that purpose directly while retaining the independent educational-resource
disclaimer.
